./scheduler_v4 FCFS homogeneous.txt   > fcfs_homogeneous.txt
./scheduler_v4 RR 1000 homogeneous.txt > rr1000_homogeneous.txt

./scheduler_v4 FCFS reverse.txt > fcfs_reverse.txt
./scheduler_v4 RR 1000 reverse.txt > rr1000_reverse.txt


